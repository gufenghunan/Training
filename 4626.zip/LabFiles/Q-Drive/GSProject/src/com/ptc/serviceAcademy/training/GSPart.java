package com.ptc.serviceAcademy.training;

import wt.part.WTPart;

import com.ptc.windchill.annotations.metadata.ForeignKeyRole;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedForeignKey;

@GenAsPersistable(superClass=WTPart.class,
	foreignKeys={
	@GeneratedForeignKey(
		foreignKeyRole=@ForeignKeyRole(name="master", type=GSPartMaster.class))
	})
public class GSPart extends _GSPart {
	static final long serialVersionUID = 1;

	public static GSPart newGSPart() throws Exception {
		final GSPart instance = new GSPart();
		instance.initialize();
		return instance;
	}
}
