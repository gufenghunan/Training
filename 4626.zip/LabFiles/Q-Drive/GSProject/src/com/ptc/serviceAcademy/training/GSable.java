package com.ptc.serviceAcademy.training;

import com.ptc.windchill.annotations.metadata.ForeignKeyRole;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedForeignKey;
import com.ptc.windchill.annotations.metadata.MyRole;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;

@GenAsPersistable(
	foreignKeys={
	@GeneratedForeignKey(
		foreignKeyRole=@ForeignKeyRole(name="simpleName", type=SimplyNamed.class, autoNavigate=true,
			constraints=@PropertyConstraints(required=true)),
		myRole=@MyRole(name="gs")
		)
	})
public interface GSable extends _GSable {
	boolean likesAnnotations();
}
