package com.ptc.serviceAcademy.training;

import wt.fc.WTObject;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.ForeignKeyRole;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedForeignKey;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.MyRole;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;
import com.ptc.windchill.annotations.metadata.TableProperties;

@GenAsPersistable(superClass=WTObject.class,
        properties={
    @GeneratedProperty(name="text", type=String.class,
    constraints=@PropertyConstraints(upperLimit=4000))
    },
    foreignKeys={
    @GeneratedForeignKey(
    foreignKeyRole=@ForeignKeyRole(name="topic", type=Topic.class),
    myRole=@MyRole(name="comment")),
    @GeneratedForeignKey(
    foreignKeyRole=@ForeignKeyRole(name="parent", type=Comment.class),
    myRole=@MyRole(name="child"))
    },
    tableProperties=@TableProperties(tableName="WTComment"))
public class Comment extends _Comment {

    static final long serialVersionUID = 1;
    public static Comment newComment() throws WTException{
        final Comment instance = new Comment();
        instance.initialize();
        return instance;
    }
}

