package com.ptc.serviceAcademy.server.annotations;

import java.lang.annotation.Documented;

@Documented
public @interface Test_Documented {
    String doTestDocument();
}
