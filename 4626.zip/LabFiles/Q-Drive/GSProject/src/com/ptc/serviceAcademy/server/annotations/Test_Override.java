package com.ptc.serviceAcademy.server.annotations;

public class Test_Override {
    @Override
    public String toString() {
        return super.toString() + "Testing annotation name: 'Override'";
    }     
}



