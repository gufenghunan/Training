package com.ptc.serviceAcademy.training;

import wt.services.ServiceFactory;
public class TrainingHelper {
    public static final TrainingService service =
        ServiceFactory.getService(TrainingService.class);
}


