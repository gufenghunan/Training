package com.ptc.serviceAcademy.training;

import wt.fc.PersistenceHelper;
import wt.part.WTPart;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class StandardTrainingService extends 
StandardManager implements TrainingService{
    private static final long serialVersionUID = 1L;
    public static StandardTrainingService 
    newStandardTrainingService() throws WTException {
        final StandardTrainingService service = new 
        StandardTrainingService();
        service.initialize();
        return service;
    }
    @Override
    public WTPart createFatherOf(String name) throws
    WTException {
        final WTPart part = WTPart.newWTPart();
        try {
            part.setName("I am your father, "+name);
        } catch (WTPropertyVetoException wtpve) {
            throw new WTException(wtpve);
        }
        return (WTPart) PersistenceHelper.manager.store(
                part);
    }
}

