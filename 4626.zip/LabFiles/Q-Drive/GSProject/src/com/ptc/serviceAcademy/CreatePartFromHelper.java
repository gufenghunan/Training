package com.ptc.serviceAcademy;

import wt.util.WTException;

import com.ptc.serviceAcademy.training.TrainingHelper;

public class CreatePartFromHelper {
    
    public static void main(String[] args) {
        try {
            TrainingHelper.service.createFatherOf("Luke");
        } catch (WTException e) {
            e.printStackTrace();
        }
    }
}
