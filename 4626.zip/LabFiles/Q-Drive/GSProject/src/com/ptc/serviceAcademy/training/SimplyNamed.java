package com.ptc.serviceAcademy.training;

import wt.fc.InvalidAttributeException;
import wt.fc.WTObject;
import wt.inf.container.WTContained;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;

@GenAsPersistable(superClass=WTObject.class, interfaces={WTContained.class},
	properties={
	@GeneratedProperty(name="name", type=String.class,
		constraints=@PropertyConstraints(required=true))
	})
public class SimplyNamed extends _SimplyNamed {
	static final long serialVersionUID = 1;
	
	public static SimplyNamed newSimplyNamed() throws WTException {
		final SimplyNamed instance = new SimplyNamed();
		instance.initialize();
		return instance;
	}
	
	@Override
	public void checkAttributes() throws InvalidAttributeException {
		super.checkAttributes();
		try {
			nameValidate(getName());
		} catch (WTPropertyVetoException wtpve) {
			throw new InvalidAttributeException(wtpve);
		}
	}
}
