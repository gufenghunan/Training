package com.ptc.serviceAcademy.training;

import wt.part.WTPartMaster;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.DerivedProperty;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;

@GenAsPersistable(superClass=WTPartMaster.class, interfaces={GSable.class},
	properties={
	@GeneratedProperty(name="custInfo", type=GSCustInfo.class)
	},
	derivedProperties={
	@DerivedProperty(name="gsType", derivedFrom="custInfo.type")
	})
public class GSPartMaster extends _GSPartMaster {
	static final long serialVersionUID = 1;

	public static GSPartMaster newGSPartMaster() throws Exception {
		final GSPartMaster instance = new GSPartMaster();
		instance.initialize();
		return instance;
	}
	@Override
	protected void initialize() throws WTException {
		super.initialize();
		custInfo = GSCustInfo.newGSCustInfo();
	}

	@Override
	public boolean likesAnnotations() {
		return getSimpleName() != null && getSimpleName().getName().equals("I like annotations!");
	}
}
