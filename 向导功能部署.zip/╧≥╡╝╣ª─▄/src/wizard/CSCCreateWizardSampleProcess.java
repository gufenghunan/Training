package ext.csc.jca.wizard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import wt.fc.PersistenceHelper;
import wt.inf.container.WTContainer;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;

public class CSCCreateWizardSampleProcess extends DefaultObjectFormProcessor {
	@Override
	public FormResult doOperation(NmCommandBean bean, List list)
			throws WTException {
		
		
		
		FormResult result = new FormResult();
		try {
			WTPart part = WTPart.newWTPart();
			HashMap map = bean.getText();
			Object[] keys = map.keySet().toArray();
			for (Object oneSet : keys) {
				if (((String) oneSet).contains("number")) {
					part.setNumber((String) map.get(oneSet));
				} else if (((String) oneSet).contains("name")) {
					part.setName((String) map.get(oneSet));
				}
			}
			WTContainer container = bean.getContainer();
			part.setContainer(container);
			PersistenceHelper.manager.save(part);
		} catch (WTPropertyVetoException pve) {
			result.setStatus(FormProcessingStatus.FAILURE);
			return result;
		} catch (WTException wte) {
			result.setStatus(FormProcessingStatus.FAILURE);
			return result;
		}
		result.setStatus(FormProcessingStatus.SUCCESS);
		return result;
	}
}
