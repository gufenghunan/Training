package ext.csc.training.resource;
 
 import wt.util.resource.RBComment;
 import wt.util.resource.RBEntry;
 import wt.util.resource.RBUUID;
 import wt.util.resource.WTListResourceBundle;
 
 @RBUUID("ext.csc.training.resource.CSCTrainingRB")
 public final class CSCTrainingRB extends WTListResourceBundle {
   @RBEntry("Wizard Sample")
   public static final String PRIVATE_CONSTANT_7 = "cscwizard.wizardSamples.description"; 
   @RBEntry("Wizard-current_step.gif")
   public static final String PRIVATE_CONSTANT_8 = "cscwizard.wizardSamples.icon"; 
   @RBEntry("Show MVC Content")
   public static final String PRIVATE_CONSTANT_9 = "cscwizard.show_mvc_content.description"; 
   @RBEntry("Show JSP Content")
   
   public static final String PRIVATE_CONSTANT_10 = "cscwizard.show_jsp_content.description"; 
   @RBEntry("Create Part Wizard")
   public static final String PRIVATE_CONSTANT_11 = "cscwizard_create_sample.createWizardSamples.description"; 
   @RBEntry("part_add.gif")
   public static final String PRIVATE_CONSTANT_12 = "cscwizard_create_sample.createWizardSamples.icon"; 
   @RBEntry("Set Part Attributes")
   public static final String PRIVATE_CONSTANT_13 = "cscwizard_create_sample.setPartAttribute.description"; 
   @RBEntry("Show Part Attributes")
   public static final String PRIVATE_CONSTANT_14 = "cscwizard_create_sample.showPartAttribute.description"; 
   @RBEntry("Show Selected Object")
   public static final String PRIVATE_CONSTANT_15 = "cscwizard_create_sample.showSelectedObject.description"; 

 }

