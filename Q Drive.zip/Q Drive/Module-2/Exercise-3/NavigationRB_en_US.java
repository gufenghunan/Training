package com.ptc.serviceAcademy.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.serviceAcademy.resource.NavigationRB")
public class NavigationRB_en_US extends WTListResourceBundle {

	@RBEntry("Services Academy")
	public static final String NAVIGATION_SERVICEACADEMY_DESCRIPTION = "navigation.serviceAcademy.description";
	
	@RBEntry("Services Academy")
	public static final String NAVIGATION_SERVICEACADEMY_TITLE = "navigation.serviceAcademy.title";
	
	@RBEntry("Services Academy")
	public static final String NAVIGATION_SERVICEACADEMY_TOOLTIP = "navigation.serviceAcademy.tooltip";
	
	@RBEntry("serviceAcademy.gif")
	public static final String NAVIGATION_SERVICEACADEMY_ICON = "navigation.serviceAcademy.icon";
	

	@RBEntry("Hello World")
	public static final String OBJECT_HELLOWORLD_DESCRIPTION = "object.helloWorld.description";
	
	@RBEntry("Hello World")
	public static final String OBJECT_HELLOWORLD_TITLE = "object.helloWorld.title";

	@RBEntry("Hello World")
	public static final String OBJECT_HELLOWORLD_TOOLTIP = "object.helloWorld.tooltip";

	
	@RBEntry("My Product List")
	public static final String OBJECT_MYPRODUCTLISTTABLE_DESCRIPTION = "object.myProductListTable.description";
	
	@RBEntry("My Product List")
	public static final String OBJECT_MYPRODUCTLISTTABLE_TITLE = "object.myProductListTable.title";

	@RBEntry("My Product List")
	public static final String OBJECT_MYPRODUCTLISTTABLE_TOOLTIP = "object.myProductListTable.tooltip";


	@RBEntry("Table Example")
	public static final String OBJECT_TABLEEXAMPLE_DESCRIPTION = "object.tableExample.description";
	
	@RBEntry("Table Example")
	public static final String OBJECT_TABLEEXAMPLE_TITLE = "object.tableExample.title";

	@RBEntry("Table Example")
	public static final String OBJECT_TABLEEXAMPLE_TOOLTIP = "object.tableExample.tooltip";
}
