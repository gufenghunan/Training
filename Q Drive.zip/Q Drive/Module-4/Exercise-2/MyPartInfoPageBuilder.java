
package com.ptc.serviceAcademy.builders;
import wt.util.WTException;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.InfoConfig;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.mvc.components.TypeBased;
import com.ptc.windchill.enterprise.part.mvc.builders.PartInfoBuilder;
@TypeBased("wt.part.WTPart|com.ptc.MyPart")
@OverrideComponentBuilder
public class MyPartInfoPageBuilder extends PartInfoBuilder {
@Override
public InfoConfig buildInfoConfig(ComponentParams params) throws WTException {
InfoConfig config = super.buildInfoConfig(params);
config.setTabSet("myPartInfoPageTabSet");
config.setView("/serviceAcademy/myPartInfoPage.jsp");
return config;
}}
