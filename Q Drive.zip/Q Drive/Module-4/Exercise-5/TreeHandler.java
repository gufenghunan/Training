package com.ptc.serviceAcademy.builders;

import java.util.*;
import com.ptc.mvc.builders.carambola.tree.CustExTreeHandler;
import wt.fc.Persistable;
import wt.fc.collections.WTArrayList;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.util.WTException;
import wt.vc.config.ConfigSpec;



public class TreeHandler extends CustExTreeHandler {
	
	private ConfigSpec configSpec;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List getRootNodes() throws WTException {
		return getRootAsParts();
	}	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<Object,List> getNodes(List parents) throws WTException {
		if (configSpec == null) {
			configSpec = getDefaultConfigSpec();
		}
		Map<Object,List> result = new HashMap <Object,List>();
		@SuppressWarnings("deprecation")
		Persistable[][][] all_children = WTPartHelper.service.getUsesWTParts(new WTArrayList(parents), configSpec);
		for(ListIterator i = parents.listIterator();i.hasNext();){
			WTPart parent = (WTPart)i.next();
			Persistable[][] branch = all_children[i.previousIndex()];
			if (branch == null){
				continue;
			}
			List children =  new ArrayList(branch.length);
			result.put(parent,children);
			for (Persistable[] child:branch)
			{
				children.add(child[1]);
			}
		}
			return result;
	}
}

	

