@RBEntry("Tree Example")
public static final String OBJECT_TREEEXAMPLE_DESCRIPTION = "object.treeExample.description";

@RBEntry("Tree Example")
public static final String OBJECT_TREEEXAMPLE_TITLE = "object.treeExample.title";

@RBEntry("Tree Example")
public static final String OBJECT_TREEEXAMPLE_TOOLTIP = "object.treeExample.tooltip";
