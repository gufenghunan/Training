package com.ptc.serviceAcademy.builders;

import wt.util.WTException;


import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TreeConfig;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NUMBER;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NAME;


@ComponentBuilder("com.ptc.serviceAcademy.builders.TreeBuilder")
public class TreeBuilder extends AbstractComponentBuilder {

	@Override
	public Object buildComponentData(ComponentConfig config, ComponentParams params) throws WTException {
		return new TreeHandler();
	}
	@Override
	public  ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TreeConfig tree = factory.newTreeConfig();
		tree.setLabel("Part Tree");
		tree.setSelectable(true);
		tree.setActionModel("CustEx_tree_toolbar");
		tree.setNodeColumn(NUMBER);
		tree.setExpansionLevel("full");
		tree.setDisableAction("false");
		tree.addComponent(factory.newColumnConfig(NAME,true));
		tree.addComponent(factory.newColumnConfig(NUMBER,true));		
		return tree;
	}
		
}

