@RBEntry("Table Example")
public static final String OBJECT_TABLEEXAMPLE_DESCRIPTION = "object.tableExample.description";

@RBEntry("Table Example")
public static final String OBJECT_TABLEEXAMPLE_TITLE = "object.tableExample.title";

@RBEntry("Table Example")
public static final String OBJECT_TABLEEXAMPLE_TOOLTIP = "object.tableExample.tooltip";