package com.ptc.serviceAcademy.builders;
 import wt.fc.*;
 import wt.part.*;
 import wt.query.QuerySpec;
 import wt.util.*;
import com.ptc.mvc.components.*;
 
 @ComponentBuilder("com.ptc.serviceAcademy.builders.TableBuilder")
public class TableBuilder extends AbstractComponentBuilder {
	 
	 @SuppressWarnings("deprecation")
	@Override
	 public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws WTException {
		 QuerySpec qs=new QuerySpec(WTPart.class);
		 qs.setQueryLimit(10000);
		 return PersistenceHelper.manager.find(qs);
		 
	 }
	 @Override
	 public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		 ComponentConfigFactory factory = getComponentConfigFactory();
		 TableConfig table = factory.newTableConfig();
		 table.setLabel("Part Table");
		 table.setSelectable(true);
		 //set the actionModel that comes in the Table Tool bar
		 table.setActionModel("mvc_tables_toolbar");
		 
		 table.addComponent(factory.newColumnConfig("name",true));
		 table.addComponent(factory.newColumnConfig("number",true));
		 table.addComponent(factory.newColumnConfig("type",true));
		 table.addComponent(factory.newColumnConfig("thePersistInfo.modifyStamp",true));
		 return table;
	 }

}
