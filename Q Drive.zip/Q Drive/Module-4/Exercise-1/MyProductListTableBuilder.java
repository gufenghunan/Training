
      package com.ptc.serviceAcademy.builders;
      
      import wt.util.WTException;
      
      import com.ptc.core.htmlcomp.components.AbstractConfigurableTableBuilder;
      import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
      import com.ptc.jca.mvc.components.JcaColumnConfig;
      import com.ptc.mvc.components.ColumnConfig;
      import com.ptc.mvc.components.ComponentBuilder;
      import com.ptc.mvc.components.ComponentConfig;
      import com.ptc.mvc.components.ComponentConfigFactory;
      import com.ptc.mvc.components.ComponentParams;
      import com.ptc.mvc.components.TableConfig;
      import com.ptc.mvc.util.ClientMessageSource;
      import com.ptc.windchill.enterprise.product.ProductClientResource;
      import com.ptc.windchill.enterprise.product.ProductList;
      import com.ptc.windchill.enterprise.product.ProductListCommand;
      
      /**
       * MVC builder class for Product List table
       */
      @ComponentBuilder("com.ptc.serviceAcademy.builders.MyProductListTableBuilder")
     public class MyProductListTableBuilder extends AbstractConfigurableTableBuilder{
          private final ClientMessageSource messageSource = getMessageSource("com.ptc.windchill.enterprise.product.ProductClientResource");
      
      
          /*
           * (non-Javadoc)
           * @see com.ptc.mvc.components.ComponentDataBuilder#buildComponentData(com.ptc.mvc.components.ComponentConfig, com.ptc.mvc.components.ComponentParams)
           */
          @Override
          public Object buildComponentData(ComponentConfig config, ComponentParams params) throws Exception {
      
        	  String tableId="com.ptc.serviceAcademy.builders.MyProductListTableBuilder";
              return ProductListCommand.getProducts(tableId);
          }
      
          @Override
          public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
              String helpContext ="ProductsHelp";
          	ComponentConfigFactory factory = getComponentConfigFactory();
              TableConfig table = factory.newTableConfig();
              table.setId("netmarkets.product.list");
              table.setConfigurable(true);
              table.setType("wt.pdmlink.PDMLinkProduct");
              table.setLabel("myTable");
              table.setActionModel("product list");
              table.setSelectable(true);
              table.setHelpContext(helpContext);
      
              ColumnConfig col1 = factory.newColumnConfig("name", true);
              col1.setInfoPageLink(true);
              col1.setSortable(true);
              table.addComponent(col1);
      
              ColumnConfig col2 = factory.newColumnConfig("infoPageAction", false);
              col2.setSortable(false);
              table.addComponent(col2);
      
              ColumnConfig col3 = factory.newColumnConfig("nmActions", false);
              col3.setSortable(false);
              table.addComponent(col3);
      
              ColumnConfig col4 = factory.newColumnConfig("containerInfo.owner", false);
              col4.setSortable(true);
              table.addComponent(col4);
      
              ColumnConfig col5 = factory.newColumnConfig("orgid", true);
              col5.setSortable(true);
              table.addComponent(col5);
      
              ColumnConfig col6 = factory.newColumnConfig("type", false);
              col6.setSortable(false);
              table.addComponent(col6);
      
              ColumnConfig col7 = factory.newColumnConfig("thePersistInfo.modifyStamp", true);
              col7.setSortable(true);
              table.addComponent(col7);
     
              ColumnConfig col8 = factory.newColumnConfig("containerInfo.description", true);
             ((JcaColumnConfig)col8).setVariableHeight(true);
      		col8.setSortable(true);
              table.addComponent(col8);
      
              ColumnConfig col9 = factory.newColumnConfig("containerInfo.creator", true);
              col9.setSortable(true);
              table.addComponent(col9);
      
             ColumnConfig col10 = factory.newColumnConfig("thePersistInfo.createStamp", true);
             col10.setSortable(true);
             table.addComponent(col10);
     
             ColumnConfig col11 = factory.newColumnConfig("containerInfo.privateAccess", true);
             col11.setSortable(true);
             table.addComponent(col11);
     
             ColumnConfig col12 = factory.newColumnConfig(ProductList.PRODUCT_TABLE_DESCRIPTION, true);
             ((JcaColumnConfig)col12).setVariableHeight(true);
             table.addComponent(col12);
    
     
             table.setShowCount(true);
     
            table.setShowCustomViewLink(false);
     		table.setView("/product/productlist.jsp");
     
             return table;
         }
     
         @Override
        public ConfigurableTable buildConfigurableTable(String id) throws WTException {
             return new ProductList();
             // TODO Auto-generated method stub
     
         }
     
     }
