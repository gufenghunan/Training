@RBEntry("My Product List")
public static final String OBJECT_MYPRODUCTLISTTABLE_DESCRIPTION = "object.myProductListTable.description";

@RBEntry("My Product List")
public static final String OBJECT_MYPRODUCTLISTTABLE_TITLE = "object.myProductListTable.title";

@RBEntry("My Product List")
public static final String OBJECT_MYPRODUCTLISTTABLE_TOOLTIP = "object.myProductListTable.tooltip";

