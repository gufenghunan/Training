package com.ptc.serviceAcademy.builders;

import java.util.*;
import wt.util.*;

import com.ptc.mvc.components.*;

@ComponentBuilder("com.ptc.serviceAcademy.builders.AttributePanelBuilder")
public class AttributePanelBuilder extends AbstractComponentBuilder {
	

	@Override
	 public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws WTException {
		
		Map<String,String> address=new HashMap<String,String>();
		address.put("name", "Parametric Technology Corp.");
		address.put("phone", "763-957-8000");
		address.put("fax", "763-957-8001");
		address.put("address1", "3785 Pheasant Ridge");
		address.put("address2", "Baline MN 55449");
		return address;
		
		

}
	@Override
	public AttributePanelConfig buildComponentConfig(ComponentParams arg0)throws WTException{
		
		ComponentConfigFactory factory = getComponentConfigFactory();
		AttributePanelConfig panelConfig = factory.newAttributePanelConfig();
		panelConfig.addComponent(getAttributeConfig("name","Name"));
		panelConfig.addComponent(getAttributeConfig("phone","Phone"));
		panelConfig.addComponent(getAttributeConfig("fax","Fax"));
		panelConfig.addComponent(getAttributeConfig("address1","Address"));
		panelConfig.addComponent(getAttributeConfig("address2",""));
		return panelConfig;
		
		
	}
	private AttributeConfig getAttributeConfig(String id, String label) {
	    AttributeConfig attributeConfig = getComponentConfigFactory().newAttributeConfig();
		attributeConfig.setId(id);
		attributeConfig.setLabel(label);
		return attributeConfig;
	}
	
}
