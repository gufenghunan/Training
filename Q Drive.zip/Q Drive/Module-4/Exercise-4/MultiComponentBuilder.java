package com.ptc.serviceAcademy.builders;

import wt.util.WTException;

import com.ptc.mvc.components.AbstractComponentConfigBuilder;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.MultiComponentConfig;
import com.ptc.mvc.components.ComponentConfig;

@ComponentBuilder(value="com.ptc.serviceAcademy.builders.MultiComponentBuilder",type=ComponentBuilderType.CONFIG_ONLY)
public class MultiComponentBuilder extends AbstractComponentConfigBuilder {

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		MultiComponentConfig multiComp = new MultiComponentConfig();
		multiComp.addNestedComponent("com.ptc.serviceAcademy.builders.AttributePanelBuilder");
		multiComp.addNestedComponent("com.ptc.serviceAcademy.builders.TableBuilder");
		multiComp.setView("/serviceAcademy/multiComponentView.jsp");
		
		return multiComp;
	}

	
}
