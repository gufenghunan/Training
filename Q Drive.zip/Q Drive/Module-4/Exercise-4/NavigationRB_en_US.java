@RBEntry("Multi Component Example")
public static final String OBJECT_MULTICOMPONENT_DESCRIPTION = "object.multiComponent.description";

@RBEntry("Multi Component Example")
public static final String OBJECT_MULTICOMPONENT_TITLE = "object.multiComponent.title";

@RBEntry("Multi Component Example")
public static final String OBJECT_MULTICOMPONENT_TOOLTIP = "object.multiComponent.tooltip";