@RBEntry("Search for Part")
public static final String OBJECT_PARTSEARCH_DESCRIPTION = "object.partSearch.description";

@RBEntry("Search for Part")
public static final String OBJECT_PARTSEARCH_TITLE = "object.partSearch.title";

@RBEntry("Search for Part")
public static final String OBJECT_PARTSEARCH_TOOLTIP = "object.partSearch.tooltip";
