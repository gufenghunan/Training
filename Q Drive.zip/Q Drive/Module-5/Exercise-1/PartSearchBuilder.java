package com.ptc.serviceAcademy.builders;

import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.CONTAINER_NAME;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.LAST_MODIFIED;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NAME;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.NUMBER;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.STATE;
import static com.ptc.core.components.descriptor.DescriptorConstants.ColumnIdentifiers.VERSION;


import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.carambola.*;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;
@SuppressWarnings("unused")
@ComponentBuilder("com.ptc.serviceAcademy.builders.PartSearchBuilder")
public class PartSearchBuilder extends AbstractComponentBuilder {
	private static final String RESOURCE = "com.ptc.carambola.carambolaResource";
	@SuppressWarnings("deprecation")
	@Override
	public Object buildComponentData(ComponentConfig  config, ComponentParams params) throws Exception {
		String number = (String) params.getParameter("number");
		String name = (String) params.getParameter("name");
		if(number != null && number.length() > 0 ) number = number.trim();
		if(name != null && name.length() > 0 ) name = name.trim();
	  	QueryResult result = null;
		QuerySpec spec = new QuerySpec(WTPart.class);
		
		if (number != null&& number.length()>0){
			spec.appendWhere(new SearchCondition(WTPart.class, "master>number" , SearchCondition.LIKE, "%"+number+"%"));
		}
		if(name!=null&&name.length()>0) {
			if (number != null&& number.length()>0) {
				spec.appendAnd();
			}
			spec.appendWhere(new SearchCondition(WTPart.class, "master>name" , SearchCondition.LIKE, "%"+name+"%"));
			}
			LatestConfigSpec latestCSpec =  new LatestConfigSpec();
		spec = latestCSpec.appendSearchCriteria(spec);
		result = PersistenceHelper.manager.find(spec);
		return result;
		}
  @Override
 public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
	ComponentConfigFactory factory = getComponentConfigFactory();
	ClientMessageSource messageSource = getMessageSource(RESOURCE);
	TableConfig table = factory.newTableConfig();
	table.setLabel(messageSource.getMessage("PART_TABLE_LABEL"));
	//make row in the table selectable
	table.setSelectable(true);
	table.addComponent(factory.newColumnConfig(NAME,false));
	//thumbnail icon
	table.addComponent(factory.newColumnConfig("smallThumbnail",false));
	table.addComponent(factory.newColumnConfig(NUMBER,false));
	table.addComponent(factory.newColumnConfig(VERSION,true));
	table.addComponent(factory.newColumnConfig(LAST_MODIFIED,true));
	table.addComponent(factory.newColumnConfig(CONTAINER_NAME,false));
	table.addComponent(factory.newColumnConfig(STATE,true));
	return table;
		
}
}

	
