package com.ptc.serviceAcademy.server.annotations;

public class Test_Depricated {
    @Deprecated
    public void doSometing(){
        System.out.println("Testing annotation name: 'Depricated'");
    }
}

