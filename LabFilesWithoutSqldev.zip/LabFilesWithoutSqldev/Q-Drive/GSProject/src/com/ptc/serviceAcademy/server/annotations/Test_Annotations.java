package com.ptc.serviceAcademy.server.annotations;

public class Test_Annotations {
    @Test_Target(doTestTarget="Hello World")
    private String str;
    public static void main(String[] args) {
        new Test_Annotations();
    }
    
    public Test_Annotations() {
        Test_Depricated t2 = new Test_Depricated();
        t2.doSometing();
    }
    /**
     * This function was used at GS-00342 "Creating your own Annotation"
     */
    /*
    @Test_Documented(doTestDocument = "Hello document")
    public void doSomeTestDocumented(){
        System.out.println("Testing annotation 'Documented'");
    }*/
    
    @Test_Target(doTestTarget="Hello World")
    public void doTestTarget(){
        System.out.println("Testing Target annotation");
    }
}

