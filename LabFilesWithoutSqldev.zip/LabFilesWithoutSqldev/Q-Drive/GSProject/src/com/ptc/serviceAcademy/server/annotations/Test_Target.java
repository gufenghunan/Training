package com.ptc.serviceAcademy.server.annotations;

public @interface Test_Target {
    public String doTestTarget();
}

