package com.ptc.serviceAcademy.training;

import wt.method.RemoteInterface;
import wt.part.WTPart;
import wt.util.WTException;

@RemoteInterface
public interface TrainingService {
    WTPart createFatherOf(final String name) throws
    WTException;
}
