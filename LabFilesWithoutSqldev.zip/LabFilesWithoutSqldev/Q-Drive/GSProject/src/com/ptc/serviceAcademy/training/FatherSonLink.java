
package com.ptc.serviceAcademy.training;

import wt.fc.ObjectToObjectLink;
import wt.fc.Persistable;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.GenAsBinaryLink;
import com.ptc.windchill.annotations.metadata.GeneratedRole;

@GenAsBinaryLink(superClass=ObjectToObjectLink.class,
        roleA=@GeneratedRole(name="father", type=SimplyNamed.class),
        roleB=@GeneratedRole(name="son", type=SimplyNamed.class))
public class FatherSonLink extends _FatherSonLink {
   static final long serialVersionUID = 1;
   
   public static FatherSonLink newFatherSonLink(final Persistable father, final Persistable son) throws WTException{
      final FatherSonLink instance = new FatherSonLink();
      instance.initialize(father, son);
      return instance;
   }
}
