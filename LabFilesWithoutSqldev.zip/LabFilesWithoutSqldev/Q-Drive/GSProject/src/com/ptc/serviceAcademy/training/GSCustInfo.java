package com.ptc.serviceAcademy.training;

import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.GenAsObjectMappable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;

@GenAsObjectMappable(
	properties={
	@GeneratedProperty(name="type", type=GSCustType.class, initialValue="GSCustType.X"),
	@GeneratedProperty(name="charged", type=boolean.class, initialValue="false")
	})
public class GSCustInfo extends _GSCustInfo {
	static final long serialVersionUID = 1;

	public static GSCustInfo newGSCustInfo() throws WTException {
		final GSCustInfo instance = new GSCustInfo();
		instance.initialize();
		return instance;
	}
	protected void initialize() throws WTException { }
}
