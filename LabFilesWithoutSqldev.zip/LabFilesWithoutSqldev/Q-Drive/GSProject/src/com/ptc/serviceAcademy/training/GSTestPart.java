package com.ptc.serviceAcademy.training;

import wt.fc.PersistenceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class GSTestPart {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			SimplyNamed sn = SimplyNamed.newSimplyNamed();
			sn.setName("I like annotations!");
			sn = (SimplyNamed) PersistenceHelper.manager.store(sn);
			GSPart gsp = GSPart.newGSPart();
			gsp.setName("My first annotated part!");
			GSPartMaster gspm = (GSPartMaster) gsp.getMaster();
			gspm.setSimpleName(sn);
			gsp = (GSPart) PersistenceHelper.manager.store(gsp);
			gspm.likesAnnotations();
			sn.setName("I hate annotations.");
			sn = (SimplyNamed) PersistenceHelper.manager.modify(sn);
			gsp = (GSPart) PersistenceHelper.manager.refresh(gsp);
			gspm.likesAnnotations();
			System.out.println("===========GSPart: '" + gsp.getName()
					+ "' has been created, its number is " + gsp.getNumber());
		} catch (WTException e) {
			e.printStackTrace();
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
