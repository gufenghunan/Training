package com.ptc.serviceAcademy.training;

import wt.fc.WTObject;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;

@GenAsPersistable(superClass=WTObject.class,
        properties={
    @GeneratedProperty(name="html", type=String.class),
    @GeneratedProperty(name="linkBait", type=String.class)
    })
public class Topic extends _Topic{
    static final long serialVersionUID = 1;
    public static Topic newTopic() throws WTException {
        final Topic instance = new Topic();
        instance.initialize();
        return instance;
    }
}
