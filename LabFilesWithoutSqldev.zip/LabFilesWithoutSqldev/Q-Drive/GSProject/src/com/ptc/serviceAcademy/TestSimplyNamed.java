package com.ptc.serviceAcademy;

import wt.fc.PersistenceHelper;

import com.ptc.serviceAcademy.training.SimplyNamed;

public class TestSimplyNamed {
    public static void main(String[] args) {
        try {
            SimplyNamed sn = SimplyNamed.newSimplyNamed();
            sn.setName("Hello from @GenAsPersistable!");
            sn.checkAttributes();
            PersistenceHelper.manager.store(sn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
