package com.ptc.serviceAcademy;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;

import com.ptc.serviceAcademy.training.FatherSonLink;
import com.ptc.serviceAcademy.training.SimplyNamed;

public class TestFatherSonLink {
    public static void main(String[] args) {
        try {
            SimplyNamed father = SimplyNamed.newSimplyNamed();
            father.setName("xshao");
            Persistable f = PersistenceHelper.manager.store(father);
            
            SimplyNamed son = SimplyNamed.newSimplyNamed();
            son.setName("wt.part.WTPart");
            Persistable s = PersistenceHelper.manager.store(son);
            Persistable fsl = PersistenceHelper.manager.store(FatherSonLink.newFatherSonLink(f, s));
            QueryResult queryResult = PersistenceHelper.manager.navigate(f, FatherSonLink.SON_ROLE, FatherSonLink.class);
            while(queryResult.hasMoreElements()) {
                System.out.println(queryResult.nextElement()+"===================");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }   
}
