package com.ptc.serviceAcademy.training;

import com.ptc.windchill.annotations.metadata.GenAsEnumeratedType;

@GenAsEnumeratedType
public class GSCustType extends _GSCustType {
	public static final GSCustType X = toGSCustType("x");
	public static final GSCustType Y = toGSCustType("y");
	public static final GSCustType Z = toGSCustType("z");
}
