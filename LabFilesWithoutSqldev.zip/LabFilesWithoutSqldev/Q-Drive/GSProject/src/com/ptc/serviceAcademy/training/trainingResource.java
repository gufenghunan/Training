package com.ptc.serviceAcademy.training;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("dummy value")
public class trainingResource extends WTListResourceBundle {
	@RBEntry("Hello, {0}")
	public static final String HELLO = "0";
}
